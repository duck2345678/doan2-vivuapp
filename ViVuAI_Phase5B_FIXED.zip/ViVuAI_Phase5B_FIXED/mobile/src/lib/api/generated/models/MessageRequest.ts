/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type MessageRequest = {
    content?: string;
    replyToId?: number;
    ConversationId?: string;
};

