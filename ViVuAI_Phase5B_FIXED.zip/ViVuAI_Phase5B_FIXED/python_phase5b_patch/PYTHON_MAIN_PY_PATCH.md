# Python FastAPI `main.py` — Phase 5B patch

The Phase 1-4 source bundle does not contain the current `app/main.py`, so this
file gives the exact minimal edits to the current main.py rather than replacing
it with an older copy.

## 1. Import `Request` and the progress context helpers

Change the FastAPI import:

```python
from fastapi import FastAPI, Request, status
```

Add:

```python
from app.tools.progress import set_progress_context, reset_progress_context
```

## 2. Add the `Request` parameter to the plan endpoint

Change:

```python
def generate_trip_plan(request: PlanGenerateRequest):
```

to:

```python
def generate_trip_plan(request: PlanGenerateRequest, http_request: Request):
```

## 3. Set the per-request progress context

Immediately before `travel_graph.invoke(...)`:

```python
request_id = http_request.headers.get("X-Request-ID") or request.session_id
progress_token = set_progress_context(request.session_id, request_id)
```

Then make sure the existing `try/except` is wrapped by a `finally` that resets it:

```python
try:
    final_state = travel_graph.invoke(_initial_state(request))
except Exception:
    logger.exception("Unhandled graph execution error")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=APIErrorResponse(
            error_code="GRAPH_EXECUTION_FAILED",
            message="Không thể thực thi quy trình lập kế hoạch.",
            session_id=request.session_id,
        ).model_dump(),
    )
finally:
    reset_progress_context(progress_token)
```

Keep the rest of the response-building code unchanged.

## 4. Environment variables

Set the same internal key on both services:

```text
AI_PYTHON_INTERNAL_SERVICE_KEY=dev-vivu-internal-key
```

Python uses this existing variable as a fallback for the progress reporter.
Optional explicit callback URL:

```text
AI_PROGRESS_CALLBACK_URL=http://localhost:8080/internal/ai/progress
AI_PROGRESS_CALLBACK_TIMEOUT_SECONDS=1.0
```

The callback is fail-open: if Spring is unavailable, progress reporting is
silently skipped and the actual AI graph continues normally.
